function SinhVien() {
    this.maSinhVien = '';
    this.tenSinhVien = '';
    this.loaiSinhVien = '';
    this.diemRenLuyen = '';
    this.email ='';
    this.soDienThoai ='';
    this.diemToan = '';
    this.diemLy = '';
    this.diemHoa = '';
}